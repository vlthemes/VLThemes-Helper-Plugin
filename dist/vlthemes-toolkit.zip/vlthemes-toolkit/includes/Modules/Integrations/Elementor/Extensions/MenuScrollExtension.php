<?php

// TODO

namespace VLT\Helper\Modules\Integrations\Elementor\Extensions;

use VLT\Helper\Modules\Integrations\Elementor\BaseExtension;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Menu Scroll Extensions
 *
 * Handles Menu Show/Hide on Scroll
 */
class MenuScrollExtensions extends BaseExtension
{

	/**
	 * Extension name
	 *
	 * @var string
	 */
	protected $name = 'menu_scroll_extensions';

	/**
	 * Initialize extension
	 */
	protected function init()
	{
		// Extension initialization
	}

	/**
	 * Register WordPress hooks
	 */
	protected function register_hooks()
	{
		// Register controls for containers
		add_action('elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 10, 2);

		// Render for containers
		add_action('elementor/frontend/container/before_render', [$this, 'render_attributes']);
	}

	/**
	 * Register Menu Scroll controls
	 *
	 * @param object $element Elementor element instance.
	 * @param array  $args    Element arguments.
	 */
	public function register_controls($element, $args)
	{

		$element->start_controls_section(
			'vlt_section_menu_scroll',
			[
				'label' => esc_html__('VLT Menu Scroll', 'vlthemes-toolkit'),
				'tab'   => \Elementor\Controls_Manager::TAB_ADVANCED,
			]
		);

		// Enable Menu Scroll
		$element->add_control(
			'vlt_menu_scroll_enabled',
			[
				'label'        => esc_html__('Enable Menu Scroll Control', 'vlthemes-toolkit'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		// Show After Scroll
		$element->add_control(
			'vlt_menu_show_after_heading',
			[
				'label'     => esc_html__('Show Settings', 'vlthemes-toolkit'),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_show_after_scroll',
			[
				'label'        => esc_html__('Show After Scroll', 'vlthemes-toolkit'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_show_after_px',
			[
				'label'       => esc_html__('Show After (px)', 'vlthemes-toolkit'),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 100,
				'min'         => 0,
				'max'         => 5000,
				'step'        => 10,
				'description' => esc_html__('Number of pixels to scroll before showing the menu', 'vlthemes-toolkit'),
				'condition'   => [
					'vlt_menu_scroll_enabled'     => 'yes',
					'vlt_menu_show_after_scroll'  => 'yes',
				],
			]
		);

		$element->add_control(
			'vlt_menu_show_animation',
			[
				'label'     => esc_html__('Show Animation', 'vlthemes-toolkit'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'fade-in',
				'options'   => [
					'fade-in'    => esc_html__('Fade In', 'vlthemes-toolkit'),
					'slide-down' => esc_html__('Slide Down', 'vlthemes-toolkit'),
					'none'       => esc_html__('None', 'vlthemes-toolkit'),
				],
				'condition' => [
					'vlt_menu_scroll_enabled'    => 'yes',
					'vlt_menu_show_after_scroll' => 'yes',
				],
			]
		);

		// Hide After Scroll
		$element->add_control(
			'vlt_menu_hide_after_heading',
			[
				'label'     => esc_html__('Hide Settings', 'vlthemes-toolkit'),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_hide_after_scroll',
			[
				'label'        => esc_html__('Hide After Scroll', 'vlthemes-toolkit'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_hide_after_px',
			[
				'label'       => esc_html__('Hide After (px)', 'vlthemes-toolkit'),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 500,
				'min'         => 0,
				'max'         => 5000,
				'step'        => 10,
				'description' => esc_html__('Number of pixels to scroll before hiding the menu', 'vlthemes-toolkit'),
				'condition'   => [
					'vlt_menu_scroll_enabled'    => 'yes',
					'vlt_menu_hide_after_scroll' => 'yes',
				],
			]
		);

		$element->add_control(
			'vlt_menu_hide_animation',
			[
				'label'     => esc_html__('Hide Animation', 'vlthemes-toolkit'),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'fade-out',
				'options'   => [
					'fade-out'  => esc_html__('Fade Out', 'vlthemes-toolkit'),
					'slide-up'  => esc_html__('Slide Up', 'vlthemes-toolkit'),
					'none'      => esc_html__('None', 'vlthemes-toolkit'),
				],
				'condition' => [
					'vlt_menu_scroll_enabled'    => 'yes',
					'vlt_menu_hide_after_scroll' => 'yes',
				],
			]
		);

		// Scroll Direction
		$element->add_control(
			'vlt_menu_scroll_direction_heading',
			[
				'label'     => esc_html__('Additional Settings', 'vlthemes-toolkit'),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_hide_on_scroll_down',
			[
				'label'        => esc_html__('Hide on Scroll Down', 'vlthemes-toolkit'),
				'description'  => esc_html__('Hide menu when scrolling down, show when scrolling up', 'vlthemes-toolkit'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => ['vlt_menu_scroll_enabled' => 'yes'],
			]
		);

		$element->add_control(
			'vlt_menu_scroll_offset',
			[
				'label'       => esc_html__('Scroll Offset (px)', 'vlthemes-toolkit'),
				'description' => esc_html__('Minimum scroll distance to trigger hide/show', 'vlthemes-toolkit'),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 10,
				'min'         => 0,
				'max'         => 200,
				'step'        => 5,
				'condition'   => [
					'vlt_menu_scroll_enabled'     => 'yes',
					'vlt_menu_hide_on_scroll_down' => 'yes',
				],
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Render Menu Scroll attributes
	 *
	 * @param object $widget Elementor widget instance.
	 */
	public function render_attributes($widget)
	{
		$settings = $widget->get_settings_for_display();

		if (isset($settings['vlt_menu_scroll_enabled']) && 'yes' === $settings['vlt_menu_scroll_enabled']) {

			$widget->add_render_attribute('_wrapper', 'class', 'vlt-menu-scroll-control');

			// Show after scroll settings
			if (isset($settings['vlt_menu_show_after_scroll']) && 'yes' === $settings['vlt_menu_show_after_scroll']) {
				$widget->add_render_attribute('_wrapper', 'data-show-after-scroll', 'true');
				$widget->add_render_attribute('_wrapper', 'data-show-after-px', $settings['vlt_menu_show_after_px']);
				$widget->add_render_attribute('_wrapper', 'data-show-animation', $settings['vlt_menu_show_animation']);
			}

			// Hide after scroll settings
			if (isset($settings['vlt_menu_hide_after_scroll']) && 'yes' === $settings['vlt_menu_hide_after_scroll']) {
				$widget->add_render_attribute('_wrapper', 'data-hide-after-scroll', 'true');
				$widget->add_render_attribute('_wrapper', 'data-hide-after-px', $settings['vlt_menu_hide_after_px']);
				$widget->add_render_attribute('_wrapper', 'data-hide-animation', $settings['vlt_menu_hide_animation']);
			}

			// Hide on scroll down
			if (isset($settings['vlt_menu_hide_on_scroll_down']) && 'yes' === $settings['vlt_menu_hide_on_scroll_down']) {
				$widget->add_render_attribute('_wrapper', 'data-hide-on-scroll-down', 'true');
				$widget->add_render_attribute('_wrapper', 'data-scroll-offset', $settings['vlt_menu_scroll_offset']);
			}
		}
	}
}
